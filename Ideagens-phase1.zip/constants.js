export const DEFAULT_COL_WIDTH = 300;
