import * as React from "react";
import ColumnMenu, { incrementString } from "./ColumnMenu";
import { useDispatch, useSelector } from "react-redux";
import RowMenu from "./RowMenu";
import readXlsxFile from "read-excel-file";
import { setColumns, setRows, setTitle } from "../../state/matrix/matrixSlice";
import {
  Chip,
  FormControl,
  Input,
  MenuItem,
  Select,
  Stack,
  TextField,
  Typography,
} from "@mui/material";
import { LicenseInfo } from "@mui/x-license-pro";
import {
  DataGridPremium,
  GridToolbarColumnsButton,
  GridToolbarContainer,
  GridToolbarDensitySelector,
  GridToolbarExport,
  GridToolbarFilterButton,
  useGridApiRef,
  useKeepGroupedColumnsHidden,
} from "@mui/x-data-grid-premium";
import styled from "styled-components";
import ClearIcon from "@mui/icons-material/Clear";
import frameworks from "./frameworks";
import { DEFAULT_COL_WIDTH } from "../../constants";

LicenseInfo.setLicenseKey(
  "aec5ab206639e137899abb37e2c619c2Tz00NDQ1MixFPTE2ODUxMTE4MjY4MzEsUz1wcmVtaXVtLExNPXN1YnNjcmlwdGlvbixLVj0y"
);

export default function Matrix() {
  const { rows, columns, title } = useSelector((state) => state.matrix);
  const [selectedRow, setSelectedRow] = React.useState();
  const [contextMenu, setContextMenu] = React.useState(null);
  const [framework, setFramework] = React.useState("Framework");
  const [version, setVersion] = React.useState("Version");
  const [rowGroupingModel, setRowGroupingModel] = React.useState([]);
  const [isGrouped, setIsGrouped] = React.useState(false);
  const dispatch = useDispatch();

  const rowGroupingModelStr = rowGroupingModel.join("-");

  const handleClose = () => {
    setContextMenu(null);
  };

  const modifyRows = (rows, isFramework) => {
    let headerName = "";
    if (isFramework) {
      headerName = "A";
    } else {
      headerName = "D";
    }
    let newCols = [];
    let newCol = {
      width: DEFAULT_COL_WIDTH,
      editable: true,
    };
    if (!isFramework) {
      rows[0].map((value, index) => {
        if (index > 3) {
          newCol = {
            ...newCol,
            field: headerName.toLowerCase(),
            headerName: headerName,
          };
          newCols.push(newCol);
          headerName = incrementString(headerName);
        }
      });

      dispatch(setColumns([...columns, ...newCols]));
    } else {
      console.log(rows[0], isFramework);
      const cols = [
        {
          field: "id",
          headerName: "S No.",
          width: 90,
          disableExport: true,
        },
      ];

      rows[0].map((value, index) => {
        const nc = {
          ...newCol,
          field: headerName.toLowerCase(),
          headerName: headerName,
        };
        headerName = incrementString(headerName);
        cols.push(nc);
      });

      dispatch(setColumns([...cols]));
      console.log(cols);
      //   newCols.push(newCol);
      // });
    }

    const modifiedRows = rows.map((row, index) => {
      let field = "a";
      let newRow = { id: index, editable: true };
      row.map((value) => {
        newRow[field] = value?.toString();
        field = incrementString(field).toLowerCase();
      });
      return newRow;
    });
    // console.log(modifiedRows);
    dispatch(setRows([...modifiedRows]));
  };

  const readExcelFile = (file, type) => {
    if (
      type === "import" &&
      file.type !==
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    ) {
      alert("Please select an excel file(.xlsx format)");
      return;
    }
    dispatch(setTitle(file?.name?.split(".").slice(0, -1).join("")));

    if (type === "import") {
      readXlsxFile(file)
        .then(modifyRows)
        .catch((error) => {
          alert("There was a problem reading this file.");
          console.log(error);
        });
    } else {
    }
  };
  const apiRef = useGridApiRef();

  const exceljsPreProcess = ({ workbook, worksheet }) => {
    workbook.created = new Date(); // Add metadata
    worksheet.name = title; // Modify worksheet name

    // Write on first line the date of creation
    // worksheet.getCell("A1").value = `Values from the`;
    // worksheet.getCell("A2").value = new Date();
  };
  function exceljsPostProcess({ worksheet }) {
    // Add a text after the data
    // worksheet.addRow(); // Add empty row
    // worksheet.removeRow(1);
    // worksheet.fileName = title; // Modify worksheet name
    // const newRow = worksheet.addRow();
    // newRow.getCell(1).value = "Those data are for internal use only";
  }

  const clearAll = () => {
    const clearedRows = rows.map((row, index) => {
      const newRow = {};
      Object.keys(row).map((key) => {
        if (key !== "id") {
          newRow[key] = "";
        }
      });
      newRow.id = index;
      return newRow;
    });
    dispatch(setRows(clearedRows));
  };

  const handleContextMenu = (event) => {
    event.preventDefault();
    setSelectedRow(Number(event.currentTarget.getAttribute("data-id")));
    setContextMenu(
      contextMenu === null
        ? { mouseX: event.clientX - 2, mouseY: event.clientY - 4 }
        : null
    );
  };

  const changeRows = (e) => {
    const before = rows.slice(0, e.id);
    const after = rows.slice(e.id + 1);
    const newRow = { ...rows[e.id], [e.field]: e.value };
    dispatch(setRows([...before, newRow, ...after]));
  };

  const groupingColDef = (params) => {
    const override = {};
    if (params.fields.includes("a")) {
      return {
        headerName: "A",
        valueFormatter: (valueFormatterParams) => {
          const rowNode = apiRef.current.getRowNode(valueFormatterParams.id);

          if (rowNode?.groupingField === "a") {
            return `by ${rowNode.groupingKey ?? ""}`;
          }
          return undefined;
        },
      };
    }
  };

  const groupRows = (col) => {
    if (isGrouped) {
      setRowGroupingModel([""]);
      setIsGrouped(false);
    } else {
      setRowGroupingModel([col]);
      setIsGrouped(true);
    }
  };

  React.useEffect(() => {
    if (framework !== "Framework" && frameworks[framework]) {
      modifyRows(frameworks[framework], true);
    }
  }, [framework]);

  return (
    <div style={{ height: "100vh", width: "100%" }}>
      <TitleRow>
        <FormControl sx={{ m: 0.5, minWidth: 120, height: 40 }}>
          <Select
            value={framework}
            style={{ height: 35 }}
            onChange={(e) => setFramework(e.target.value)}
            displayEmpty
            inputProps={{ "aria-label": "Without label" }}
          >
            <MenuItem value="Framework">Framework</MenuItem>
            <MenuItem value="5M+2S">5M + 2S</MenuItem>
            <MenuItem value="Risk Analysis">Risk Analysis</MenuItem>
          </Select>
        </FormControl>
        <Input
          id="outlined-basic"
          placeholder="Problem/Goal"
          variant="outlined"
          value={title}
          onChange={(e) => dispatch(setTitle(e.target.value))}
        />

        <FormControl sx={{ m: 0.5, minWidth: 120 }}>
          <Select
            value={version}
            onChange={(e) => setVersion(e.target.value)}
            displayEmpty
            style={{ height: 35 }}
            inputProps={{ "aria-label": "Without label" }}
          >
            <MenuItem value="Version">Version</MenuItem>
            <MenuItem value="Public">Public</MenuItem>
            <MenuItem value="Private">Private</MenuItem>
          </Select>
        </FormControl>
      </TitleRow>
      <DataGridPremium
        rows={rows}
        checkboxSelection
        columns={columns}
        apiRef={apiRef}
        disableSelectionOnClick
        // initialState={initialState}
        groupingColDef={groupingColDef}
        rowGroupingModel={rowGroupingModel}
        components={{
          ColumnMenu: (column) => {
            return <ColumnMenu currentColumn={column.currentColumn} />;
          },
          Toolbar: () => (
            <GridToolbarContainer>
              <Stack
                sx={{ width: "100%", mb: 1 }}
                direction="row"
                alignItems="flex-start"
                columnGap={1}
              >
                <Chip
                  label="Group by col A"
                  onClick={() => groupRows("a")}
                  variant="outlined"
                  color={rowGroupingModelStr === "a" ? "primary" : undefined}
                />
                <Chip
                  label="Group by col B"
                  onClick={() => groupRows("b")}
                  variant="outlined"
                  color={rowGroupingModelStr === "b" ? "primary" : undefined}
                />
              </Stack>
              <GridToolbarColumnsButton />
              <GridToolbarFilterButton />
              <GridToolbarDensitySelector />
              <GridToolbarExport
                excelOptions={{
                  exceljsPreProcess,
                  exceljsPostProcess,
                  fileName: title,
                  includeHeaders: false,
                }}
              />

              <ClearAll onClick={clearAll}>
                <ClearIcon color="primary" />
                <Typography fontSize={15} color="primary" component="h6">
                  Clear All
                </Typography>
              </ClearAll>
              <input
                type="file"
                id="import-file"
                onChange={(e) => readExcelFile(e.target.files[0], "import")}
              />
            </GridToolbarContainer>
          ),
        }}
        onCellEditCommit={(e) => changeRows(e)}
        componentsProps={{
          row: {
            onContextMenu: handleContextMenu,
            style: { cursor: "context-menu" },
          },
        }}
      />

      <RowMenu
        selectedRow={selectedRow}
        contextMenu={contextMenu}
        handleClose={handleClose}
      />
    </div>
  );
}

const TitleRow = styled.div`
  display: flex;
  justify-content: space-around;
`;

const ClearAll = styled.div`
  display: inline-flex;
  align-items: center;
  cursor: pointer;
  padding-right: 5px;
`;
